
package undip.dao.transferObject;

public class Dosen {
    private int id;
    private int nip;
    private String nama;

    public Dosen() {
        this(0, 0, "");
    }
    
    public Dosen(int id, int nip, String nama) {
        this.id = id;
        this.nip = nip;
        this.nama = nama;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNip() {
        return nip;
    }

    public void setNip(int nip) {
        this.nip = nip;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    @Override
    public String toString() {
        return "Dosen{" + "id=" + id + ", nip=" + nip + ", nama=" + nama + '}';
    }
    
    

}
