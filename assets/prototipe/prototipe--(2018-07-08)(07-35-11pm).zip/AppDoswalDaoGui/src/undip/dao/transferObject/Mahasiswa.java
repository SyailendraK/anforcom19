package undip.dao.transferObject;

import java.util.Date;

public class Mahasiswa {
    private int id;
    private String nama;
    private Dosen dosenWali;

    public Mahasiswa() {
        this(0, "", null);
    }

    public Mahasiswa(int id, String nama, Dosen dosenWali) {
        this.id = id;
        this.nama = nama;
        this.dosenWali = dosenWali;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public Dosen getDosenWali() {
        return dosenWali;
    }

    public void setDosenWali(Dosen dosenWali) {
        this.dosenWali = dosenWali;
    }

    @Override
    public String toString() {
        return "Mahasiswa{" + "id=" + id + ", nama=" + nama + ", dosenWali=" + dosenWali + '}';
    }
    
    
}
