package undip.dao.dao;

import undip.dao.transferObject.Dosen;
import undip.utilities.MysqlUtility;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DosenDaoMysql {

    Connection koneksi;

    public DosenDaoMysql() {
        koneksi = MysqlUtility.getConnection();
    }

    public Dosen makeDosenObject() {
        return new Dosen();
    }

    public void insert(Dosen dsn) {
        PreparedStatement prepare = null;

        try {
            String sql = "INSERT INTO dosen (id, nip, namaDosen) VALUES (?,?,?);";
            prepare = koneksi.prepareStatement(sql);

            prepare.setInt(1, dsn.getId());
            prepare.setInt(2, dsn.getNip());
            prepare.setString(3, dsn.getNama());

            prepare.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Gagal membuat prepare : " + ex.getMessage());
            System.out.println(ex.getStackTrace());
        } finally {
            if (prepare != null) {
                try {
                    prepare.close();
                } catch (Exception e) {
                    System.out.println("Gagal menutup prepare");
                }
            }
        }
    }

    public void update(Dosen dsn) {

    }

    public void delete(int dosenId) {
        PreparedStatement prepare = null;
        try {
            String sql = "DELETE from dosen WHERE id = ?;";
            prepare = koneksi.prepareStatement(sql);

            prepare.setInt(1, dosenId);

            prepare.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Gagal membuat prepare : " + ex.getMessage());
        } finally {
            if (prepare != null) {
                try {
                    prepare.close();
                } catch (Exception e) {
                    System.out.println("Gagal menutup prepare");
                }
            }
        }
    }

    public Dosen selectById(int idDoswal) {
        PreparedStatement prepare = null;
        ResultSet result = null;
        Dosen dsn = null;

        try {
            String sql = "SELECT * from dosen WHERE id = ?;";
            prepare = koneksi.prepareStatement(sql);

            prepare.setInt(1, idDoswal);

            result = prepare.executeQuery();

            if (result.next()) {
                dsn = new Dosen();

                dsn.setId(result.getInt("id"));
                dsn.setNama(result.getString("namaDosen"));
                dsn.setNip(result.getInt("nip"));

            }

            return dsn;

        } catch (SQLException ex) {
            System.out.println("Gagal membuat prepare : " + ex.getMessage());
            return dsn;
        } finally {
            if (prepare != null) {
                try {
                    prepare.close();
                } catch (Exception e) {
                    System.out.println("Gagal menutup prepare");
                }
            }
            if (result != null) {
                try {
                    result.close();
                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        }
    }

    public Dosen selectByNama(String namaDsn) {
        PreparedStatement prepare = null;
        ResultSet result = null;
        Dosen dsn = null;

        try {
            String sql = "SELECT * from dosen WHERE namaDosen = ?;";
            prepare = koneksi.prepareStatement(sql);

            prepare.setString(1, namaDsn);

            result = prepare.executeQuery();

            if (result.next()) {
                dsn = new Dosen();

                dsn.setId(result.getInt("id"));
                dsn.setNama(result.getString("namaDosen"));
                dsn.setNip(result.getInt("nip"));

            }

            return dsn;

        } catch (SQLException ex) {
            System.out.println("Gagal membuat prepare : " + ex.getMessage());
            return dsn;
        } finally {
            if (prepare != null) {
                try {
                    prepare.close();
                } catch (Exception e) {
                    System.out.println("Gagal menutup prepare");
                }
            }
            if (result != null) {
                try {
                    result.close();
                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        }
    }

    public List<Dosen> selectAll() {
        PreparedStatement prepare = null;
        ResultSet result = null;
        List<Dosen> dsns = new ArrayList<>();

        try {
            String sql = "SELECT * from dosen;";
            prepare = koneksi.prepareStatement(sql);

            result = prepare.executeQuery();

            while (result.next()) {
                Dosen dsn = new Dosen();
                dsn.setId(result.getInt("id"));
                dsn.setNama(result.getString("namaDosen"));
                dsn.setNip(result.getInt("id"));

                dsns.add(dsn);
            }
            return dsns;

        } catch (SQLException ex) {
            System.out.println("DosenService Gagal membuat prepare : " + ex.getMessage());
            return dsns;
        } finally {
            if (prepare != null) {
                try {
                    prepare.close();
                } catch (Exception e) {
                    System.out.println("Gagal menutup prepare");
                }
            }
            if (result != null) {
                try {
                    result.close();
                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        }
    }


}
