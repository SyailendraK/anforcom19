package undip.dao.dao;

import undip.dao.transferObject.Mahasiswa;
import undip.utilities.MysqlUtility;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MahasiswaDaoMysql {

    Connection koneksi;

    public MahasiswaDaoMysql() {
        koneksi = MysqlUtility.getConnection();
    }

    public Mahasiswa makeMhsObject() {
        return new Mahasiswa();
    }

    public void insert(Mahasiswa mhs) {
        PreparedStatement prepare = null;

        try {
            String sql = "INSERT INTO mahasiswa (id, nama, dosenId) VALUES (?,?,?);";
            prepare = koneksi.prepareStatement(sql);
            prepare.setInt(1, mhs.getId());
            prepare.setString(2, mhs.getNama());
            prepare.setInt(3, mhs.getDosenWali().getId());

            prepare.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("MhsDAO Gagal membuat prepare : " + ex.getMessage());
        } finally {
            if (prepare != null) {
                try {
                    prepare.close();
                    System.out.println("Sukses menutup prepare");
                } catch (Exception e) {
                    System.out.println("Gagal menutup prepare");
                }
            }
        }
    }

    public void update(Mahasiswa mhs, int idLama) {
        PreparedStatement prepare = null;
        try {
            String sql = "UPDATE mahasiswa m, dosen d "
                    + "SET m.id = ?, m.nama = ?, m.dosenId= ? "
                    + "WHERE m.id = ? ";
            prepare = koneksi.prepareStatement(sql);

            prepare.setInt(1, mhs.getId());
            prepare.setString(2, mhs.getNama());
            prepare.setInt(3, mhs.getDosenWali().getId());
            prepare.setInt(4, idLama);

            prepare.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Gagal membuat prepare : " + ex.getMessage());
        } finally {
            if (prepare != null) {
                try {
                    prepare.close();
                } catch (Exception e) {
                    System.out.println("Gagal menutup prepare");
                }
            }
        }
    }

    public void delete(int id) {
        PreparedStatement prepare = null;
        try {
            String sql = "DELETE from mahasiswa WHERE id = ?;";
            prepare = koneksi.prepareStatement(sql);

            prepare.setInt(1, id);

            prepare.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Gagal membuat prepare : " + ex.getMessage());
        } finally {
            if (prepare != null) {
                try {
                    prepare.close();
                } catch (Exception e) {
                    System.out.println("Gagal menutup prepare");
                }
            }
        }
    }

    public Mahasiswa selectById(int id) {
        PreparedStatement prepare = null;
        ResultSet result = null;
        Mahasiswa mhs = null;

        try {
            String sql = "SELECT * from mahasiswa WHERE id = ?;";

            prepare = koneksi.prepareStatement(sql);

            prepare.setInt(1, id);

            result = prepare.executeQuery();

            if (result.next()) {
                mhs = new Mahasiswa();
                int idDosen = result.getInt("dosenId"); // ambil id dosen

                DosenDaoMysql dsnService = new DosenDaoMysql();
                mhs.setDosenWali(dsnService.selectById(idDosen)); // ambil objek dosen
                mhs.setId(result.getInt("id"));
                mhs.setNama(result.getString("nama"));

            }

            return mhs;

        } catch (SQLException ex) {
            System.out.println("Gagal membuat prepare : " + ex.getMessage());
            return mhs;
        } finally {
            if (prepare != null) {
                try {
                    prepare.close();
                } catch (Exception e) {
                    System.out.println("Gagal menutup prepare");
                }
            }
            if (result != null) {
                try {
                    result.close();
                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        }
    }

    public List<Mahasiswa> selectAll() {
        PreparedStatement prepare = null;
        ResultSet result = null;
        List<Mahasiswa> mhss = new ArrayList<>();

        try {
            String sql = "SELECT * from mahasiswa;";
            prepare = koneksi.prepareStatement(sql);

            result = prepare.executeQuery();

            while (result.next()) {
                Mahasiswa mhs = new Mahasiswa();
                int idDosen = result.getInt("dosenId"); // ambil id dosen

                DosenDaoMysql dsnService = new DosenDaoMysql();
                mhs.setDosenWali(dsnService.selectById(idDosen));// ambil objek dosen
                mhs.setId(result.getInt("id"));
                mhs.setNama(result.getString("nama"));

                mhss.add(mhs);
            }
            return mhss;

        } catch (SQLException ex) {
            System.out.println("Gagal membuat prepare : " + ex.getMessage());
            return mhss;
        } finally {
            if (prepare != null) {
                try {
                    prepare.close();
                } catch (Exception e) {
                    System.out.println("Gagal menutup prepare");
                }
            }
            if (result != null) {
                try {
                    result.close();
                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        }
    }


}
